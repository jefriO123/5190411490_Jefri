@extends('layouts.main')

@section('title','Profile')

@section('article')
    <h1>Ini adalah Profile</h1>
@endsection