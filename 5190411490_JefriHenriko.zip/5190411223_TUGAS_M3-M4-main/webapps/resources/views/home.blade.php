@extends('layouts.main')

@section('title','Home')

@section('article')
    <h1>Ini adalah Home</h1>
@endsection